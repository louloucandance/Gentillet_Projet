package Client;

public class VoeuxTerrain extends Voeux  {

}
