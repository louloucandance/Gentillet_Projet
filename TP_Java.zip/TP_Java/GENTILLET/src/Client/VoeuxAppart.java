package Client;

public class VoeuxAppart extends Voeux {

}
