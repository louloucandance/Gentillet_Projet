package Client;

public class VoeuxMaison extends Voeux  {

}
