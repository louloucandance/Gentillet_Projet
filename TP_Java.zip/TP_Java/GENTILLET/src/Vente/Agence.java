package Vente;

public class Agence {
	private String nom;

}
