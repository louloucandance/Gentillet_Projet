package Vente;

public class MandatVente {

}
