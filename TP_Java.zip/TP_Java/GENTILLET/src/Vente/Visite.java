package Vente;

public class Visite {

}
